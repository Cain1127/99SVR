//
//  ZipArchiveCell.h
//  Zippo
//
//  Created by Stefan Gugarel on 3/15/13.
//  Copyright (c) 2013 Drobnik KG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZipArchiveCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIProgressView *progressView;

@end
