//
//  ViewController.h
//  DTAnimatedGIF Demo
//
//  Created by Oliver Drobnik on 7/2/14.
//  Copyright (c) 2014 Cocoanetics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GIFViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
