//
//  ViewController.h
//  DTReachability Demo
//
//  Created by Oliver Drobnik on 5/31/13.
//  Copyright (c) 2013 Cocoanetics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *label;

@end
