//
//  DTBlockFunctionsTest.h
//  DTFoundation
//
//  Created by Oliver Drobnik on 02.10.13.
//  Copyright (c) 2013 Cocoanetics. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface DTBlockFunctionsTest : XCTestCase

@end
