//
//  DTZipArchiveTest.h
//  DTFoundation
//
//  Created by Stefan Gugarel on 23.01.13.
//  Copyright (c) 2013 Cocoanetics. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <XCTest/XCTest.h>

@interface DTZipArchiveTest : XCTestCase

@end