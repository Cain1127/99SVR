//
//  NSArray+DTErrorTest.h
//  DTFoundation
//
//  Created by Stefan Gugarel on 10/18/12.
//  Copyright (c) 2012 Cocoanetics. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface NSArrayDTErrorTest : XCTestCase

@end
