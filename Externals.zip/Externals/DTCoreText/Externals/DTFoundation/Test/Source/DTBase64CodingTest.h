//
//  DTBase64CodingTest.h
//  DTFoundation
//
//  Created by Oliver Drobnik on 04.03.13.
//  Copyright (c) 2013 Cocoanetics. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface DTBase64CodingTest : XCTestCase

@end
