//
//  DTFoundationConstants.m
//  DTFoundation
//
//  Created by Stefan Gugarel on 10/18/12.
//  Copyright (c) 2012 Cocoanetics. All rights reserved.
//

#import "DTFoundationConstants.h"

NSString * const DTFoundationErrorDomain = @"DTFoundation";